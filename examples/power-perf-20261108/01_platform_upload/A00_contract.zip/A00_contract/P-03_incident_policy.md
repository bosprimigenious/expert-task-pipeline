# P-03｜事故、责任与文书效力（题设模拟制度）
source_id: P-03。12起case_id为物理事故登记号。每案两张工单仅为同一事故的跟踪记录，不另计处罚。
## 权限与时点
只有issuer=COMMITTEE、document_kind为FINAL或REVOKED、known_at/effective_at/非空served_at均不晚于截点的文书，才具有本次裁决效力。先过滤这些条件，再按version、known_at、document_id选最大有效文书。DRAFT、部门意见、未送达、未来文书不能替代现有有效决定；申诉受理也不自动中止。
存在有效REVOKED时，该案历史处罚及降级、封顶在该视图取消，状态REVOKED，不恢复上一份已撤销决定。存在有效FINAL时按finding处理。没有有效文书时状态PENDING；initial_allegation只用于确定待补证影响的责任单位，不是最终责任真值。
## 处罚与责任
DEVICE：事件日设备管理单位扣8分，该单位等级最高C；运行单位不因此另扣。
OPERATION：事件日运行单位扣10分，等级最高C；设备单位不因此另扣。
EQUAL：设备方扣4分，运行方扣5分，双方各降一级。8与10分别减半，不能一律各扣4。
EXTERNAL：非责任，双方扣0，不附带限级。
NETWORK：信息安全归口单位扣12分，最高D；NET01的设备与运行字段均映射U6，但只计一次12分。
多案同一单位扣分相加；同一案在多个工单/报告中出现不重复加。每案单独提供角色、扣分、shift与cap。
## 待定范围
PENDING的DEVICE/NETWORK影响设备方；OPERATION影响运行方；EQUAL影响双方。只影响这些单位的正式终评，不把全公司全部置为未知。实际整改完成不自动改变历史责任，补证计划也不代表证据已获得。
## 等级限制
cap采用A/B/C/D的最高可评等级，A表示无限制。多案cap取最严格者；同等责任shift逐案累加。合并运算顺序在P-04定义，不因看见“最高C”就先封顶后降级。
