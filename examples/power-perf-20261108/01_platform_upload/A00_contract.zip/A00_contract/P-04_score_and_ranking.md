# P-04｜汇总、等级、排名与工作簿要求（题设模拟制度）
source_id: P-04。
1. 已知项暂计分=max(0,100−已确定的K1…K4扣分−已经生效事故扣分)。未决扣分不作为0分事实，只是不计入暂计小计。用score_status=PROVISIONAL明确这一限制。
2. 若单位有任一UNDETERMINED指标或PENDING事故，final_score空、final_grade=HOLD、rank空；保留provisional_score及pending_items。无未决时final_score=provisional_score、score_status=FINAL。
3. 按未舍入的provisional_score生成raw_grade：A≥90，B≥80，C≥70，否则D。先对raw_grade累计同等责任降级（最多降到D），然后应用最严格等级上限。A=1…D=4时，final_rank=max(min(4,raw_rank+shift_count),cap_rank)。HOLD覆盖最终等级但不删除可核对的raw_grade。
4. 只对FINAL单位排名。先按final_grade A至D，再在同等级按未舍入final_score从高到低；同等级同分并列，采用competition rank（如1、1、3）。不要把HOLD作0分排在末尾。
5. 工作簿至少具备任务要求的9张工作表。输入选择和文书裁决可以保留已核定值，但K1半年度聚合、其他年度率/扣分、总分、等级和排名需有公式引用。禁止只把Python计算结果粘贴成值后称为公式模型。允许增加说明列、工作表，公式不要求与参考解字符串相同。
6. 合理地修复旧工作簿，不要求保留错误公式。必须列出错误位置、影响、修复原则与实际检查；格式美观不替代业务正确性。工作簿中的业务分不是受测模型的评分。
