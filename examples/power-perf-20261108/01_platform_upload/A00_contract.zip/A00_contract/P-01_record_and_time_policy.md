# P-01｜记录、时间与归口政策（题设模拟制度）
source_id: P-01。性质：BENCHMARK_STIPULATED，仅适用于本演练。
## 1. 时间可见性
先按known_at<=视图截点筛选；读取到文件不代表在历史时点已知。区间均为闭区间。业务日期决定归属期间，known_at决定是否可纳入。RB从完整原始资料按R0截点重新计算，不从终评值倒扣。
## 2. 台账版本
ENERGY主键为feeder_id+period+measure；BILL为invoice_id；OUTAGE为outage_id；COMPLAINT为ticket_id。先删除reason=DUPLICATE_EXPORT，再筛known_at，再按version（整数）、known_at、record_id字典序选择最大的一条。最大version不是未经可见性筛选的全局最大值。最终CANCELLED时该组合无有效值，不允许恢复旧POSTED。其余POSTED才能进入计算。后续POSTED可恢复组合。每条剔除记录按优先顺序归入DUPLICATE_EXPORT、AFTER_CUTOFF、SUPERSEDED或LATEST_CANCELLED中的唯一原因。selected_records保留最后一条及其状态，包括CANCELLED；exception_log还要记录该CANCELLED不进入计算。
## 3. 单位与组织
kWh与10k_kWh相差10,000倍，转换到kWh。真布尔使用字符串true/false语义，不按非空即真。合法别名见unit_aliases.csv，日期范围内映射；其他新别名不得猜测。
assignment_id是职责文书逻辑主键；每个截点先选最大有效可知版本，再按资产与业务日期查区间。每个资产每天恰有一条职责记录；否则该部分报告未决。月度计量、可靠率按该月1日有效归口；事故按实际event_date。资产设备责任人与运行责任人独立。F18交接更正属于事后获知的追溯更正，只改变后续视图，不污染R0/RB。
## 4. 缺失
customer_exposure.csv是本题声明完整的配网计量覆盖名册，每个feeder+period应具有supply和sold各一条有效值。任一侧缺失，该月相应单位K1未决；不补零、不忽略该馈线、不采用旧记录。K2的曝光量来源独立，不因此自动未知。其他台账只按本规则已声明完整的组合计算。
## 5. 清洗记录
selected_records四族分别保存来源主键、所选record_id、status和source_id。exception_log记录被剔除的原始行及原因。所有原始文件只读，任何转换均在新工作目录完成。
