"""Public structural checker only. Passing does NOT establish business correctness."""
from pathlib import Path
import csv,json,argparse
p=argparse.ArgumentParser();p.add_argument('--submission',required=True);a=p.parse_args();root=Path(a.submission);schema=json.loads(Path(__file__).with_name('output_schema.json').read_text(encoding='utf-8'));checks=[]
for fn,s in schema['files'].items():
 try:
  with (root/fn).open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
  ok=bool(rows) and set(s['columns'])<=set(rows[0]) and len({tuple(r[k] for k in s['key']) for r in rows})==len(rows)
  checks.append({'file':fn,'structural_check':'PASS' if ok else 'FAIL','rows':len(rows)})
 except Exception as e: checks.append({'file':fn,'structural_check':'FAIL','error':str(e)})
print(json.dumps({'scope':'STRUCTURE_ONLY_NOT_A_SCORE','checks':checks},ensure_ascii=False,indent=2))
raise SystemExit(0 if all(c['structural_check']=='PASS' for c in checks) else 1)
