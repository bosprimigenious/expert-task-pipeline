# A06 交付与旧稿复核
legacy_review.xlsx和legacy_claims.csv均为待审旧稿，不是权威制度或标准答案。请保留足以定位其问题的审核记录；无须逐字复刻参考工作簿。
output_schema.json定义必须提交的数据接口。review_actions和review_plan_contract定义补证规划。
全部规则已公开；没有网页服务、口令、分阶段提交工具或私人路径。文件数量不是得分或步数的替代指标。

## 工作簿数据接口（不是版式限制）
Review Summary表保留final_decisions.csv对应字段名作为一行表头；Indicator Model保留indicator_results.csv中的snapshot、unit_id、indicator、numerator、denominator、rate、penalty、status字段名。可另加中文展示列、说明、图表；表头行号、列顺序和单元格位置不限。其他工作表可以自行布局。汇总表保留指标扣分、事故扣分、暂计分与等级/排名的引用公式；已确定指标的分子分母汇总、完成值及扣分保留公式。原始记录选择、单位映射和业务裁决可以作为经审计的输入，不要求将文字判断写成公式。交付前重新计算保存，便于独立核验；不得以硬编码结果冒充公式。
