# A03 应收、豁免与投诉
receivables为余额式修订表，版本替代而非增量；waivers的金额为元，不是万元。CITY_GOV、DEPT等都是模拟授权枚举。
complaints可跨渠道重复描述同一客户同一事件；不要把三渠道工单总数直接当唯一投诉数。false是布尔假，不是非空即真。
customer_base是全年平均客户数，不能当12个月新增数累加。
